import static java.lang.System.out;

public class Names {
    String firstName;
    String lastName;
    String fatherness;

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getFatherness() {
        return fatherness;
    }
    public void setFatherness(String fatherness) {
        this.fatherness = fatherness;
    }

    public Names(String lastName, String firstName, String fatherness) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.fatherness = fatherness;
        out.println("Object created. Firstname = \"" + firstName + "\"; Lastname = \"" + lastName + "\"; Fatherness = \"" + fatherness + "\".");
    }

    public Names(String firstName) {
        this("", firstName, "");
    }

    public Names(String lastName, String firstName) {
        this(lastName, firstName, "");
    }

    public String getName() {
        return String.format("%s %s %s", firstName, lastName, fatherness);
    }
}
