import static java.lang.System.out;

public class Box<type> {
    type object;

    public type get() {
        type t = object;
        object = null;
        out.println("Из коробки извлечён объект.");
        return t;
    }

    public void set(type t) throws Exception {
        if (object != null) {
            throw new Exception("Box is already full.");
        }
        else {
            object = t;
            out.println("В коробку введён объект.");
        }
    }

    Box(type object){
        this.object = object;
        out.println("Создана коробка.\nВ коробку введён объект.");
    }

    public Box(){
        this(null);
        out.println("Создана коробка.");
    }

    public boolean isEmpty(){
        out.println("Проверка коробки на заполненность.");
        return object == null;
    }
}
