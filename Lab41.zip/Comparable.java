public interface Comparable<T> {
    int Compare(T obj);
}
