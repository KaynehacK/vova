public class Ob1 {
    int n;
    String s;
    double d;
    boolean b;

    public int getN() {return n;}
    public void setN(int n) {this.n = n;}
    public String getS() {return s;}
    public void setS(String s) {this.s = s;}
    public double getD() {return d;}
    public void setD(double d) {this.d = d;}
    public boolean getB() {return b;}
    public void setB(boolean b) {this.b = b;}

    Ob1(int n, String s, double d, boolean b) {
        this.n = n;
        this.s = s;
        this.d = d;
        this.b = b;
    }

    public Ob1() {
        this(0, null, 0, true);
    }
}
