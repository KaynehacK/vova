public class Box<type> {
    type object;

    public type get() {
        type t = object;
        object = null;
        return t;
    }

    public void set(type t) throws Exception {
        if (object != null) {
            throw new Exception("Box is already full.");
        }
        object = t;
    }

    Box(type object){
        this.object = object;
    }

    Box(){
        this(null);
    }

    public boolean isEmpty(){
        return object == null;
    }
}
