import java.util.Scanner;
import static java.lang.System.out;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        out.printf("Enter a code of task in accordance with a table:\n" +
                "Task code:\t| 1 | 2 | 3 | 4 | 5 | 6 |\n" +
                "Task number:|1.2|1.3|2.4|3.4|4.5|5.1|\n" +
                "Code of task: ");
        int task = in.nextInt();
        switch (task) {
            case 1: {
                out.println("Задание 1.2: Класс Коробка для хранения обекта любого типа.");
                Box<Integer> b1 = new Box<>(3);
                out.println(String.valueOf( function0( b1.get() ) ));
                try {
                    b1.set(10);
                    out.println(String.valueOf( b1.get() ));
                } catch (Exception e) {
                    out.println(e.getMessage());
                }
                out.println(String.valueOf( b1.isEmpty() ));
                break;
                Ob1 o1 = new Ob1();
                Box<Ob1> b2;
                b2 = new Box<>(o1);
                out.println( String.valueOf(b2.get().getD()) );
            }
        }
    }

    public static int function0(int x){
        return x * 10;
    }
}